CREATE TRIGGER ClientTrigger
on Client 
after update,insert
as 
begin 
print 'This client has been updated or inserted.'
end
go

