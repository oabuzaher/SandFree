
CREATE PROCEDURE [dbo].sp_Warehouse_Update
(
	@Name varchar(50),
	@Address varchar(100),
	@City varchar(50),
	@StateProvinceCode varchar(20),
	@PostalCode int,
	@IsActive bit,
	@Original_WarehouseID int,
	@IsNull_Name Int,
	@Original_Name varchar(50),
	@IsNull_Address Int,
	@Original_Address varchar(100),
	@IsNull_City Int,
	@Original_City varchar(50),
	@IsNull_StateProvinceCode Int,
	@Original_StateProvinceCode varchar(20),
	@IsNull_PostalCode Int,
	@Original_PostalCode int,
	@Original_IsActive bit,
	@WarehouseID int
)
AS
	SET NOCOUNT OFF;
UPDATE [Warehouse] SET [Name] = @Name, [Address] = @Address, [City] = @City, [StateProvinceCode] = @StateProvinceCode, [PostalCode] = @PostalCode, [IsActive] = @IsActive WHERE (([WarehouseID] = @Original_WarehouseID) AND ((@IsNull_Name = 1 AND [Name] IS NULL) OR ([Name] = @Original_Name)) AND ((@IsNull_Address = 1 AND [Address] IS NULL) OR ([Address] = @Original_Address)) AND ((@IsNull_City = 1 AND [City] IS NULL) OR ([City] = @Original_City)) AND ((@IsNull_StateProvinceCode = 1 AND [StateProvinceCode] IS NULL) OR ([StateProvinceCode] = @Original_StateProvinceCode)) AND ((@IsNull_PostalCode = 1 AND [PostalCode] IS NULL) OR ([PostalCode] = @Original_PostalCode)) AND ([IsActive] = @Original_IsActive));
	
SELECT WarehouseID, Name, Address, City, StateProvinceCode, PostalCode, IsActive FROM Warehouse WHERE (WarehouseID = @WarehouseID)
go

