
CREATE PROCEDURE [dbo].sp_Link_ServiceList_ItemList_Create
(
	@ServiceListID int,
	@ItemListID int
)
AS
	SET NOCOUNT OFF;
INSERT INTO [Link_ServiceList_ItemList] ([ServiceListID], [ItemListID]) VALUES (@ServiceListID, @ItemListID);
	
SELECT ServiceListID, ItemListID FROM Link_ServiceList_ItemList WHERE (ItemListID = @ItemListID) AND (ServiceListID = @ServiceListID)
go

