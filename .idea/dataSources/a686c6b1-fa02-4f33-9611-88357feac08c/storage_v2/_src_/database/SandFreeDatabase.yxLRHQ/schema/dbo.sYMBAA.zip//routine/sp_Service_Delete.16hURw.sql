
CREATE PROCEDURE [dbo].sp_Service_Delete
(
	@Original_ServiceID int,
	@IsNull_JobID Int,
	@Original_JobID int,
	@IsNull_Description Int,
	@Original_Description varchar(255),
	@IsNull_Name Int,
	@Original_Name varchar(50)
)
AS
	SET NOCOUNT OFF;
DELETE FROM [Service] WHERE (([ServiceID] = @Original_ServiceID) AND ((@IsNull_JobID = 1 AND [JobID] IS NULL) OR ([JobID] = @Original_JobID)) AND ((@IsNull_Description = 1 AND [Description] IS NULL) OR ([Description] = @Original_Description)) AND ((@IsNull_Name = 1 AND [Name] IS NULL) OR ([Name] = @Original_Name)))
go

