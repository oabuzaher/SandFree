
CREATE PROCEDURE [dbo].[sp_EmployeeIncident_Update]
(
	@EmployeeID int,
	@Date datetime,
	@Description varchar(255),
	@Original_EmployeeIncidentID int,
	@IsNull_EmployeeID Int,
	@Original_EmployeeID int,
	@IsNull_Date Int,
	@Original_Date datetime,
	@IsNull_Description Int,
	@Original_Description varchar(255),
	@EmployeeIncidentID int
)
AS
	SET NOCOUNT OFF;
UPDATE [EmployeeIncident] SET [EmployeeID] = @EmployeeID, [Date] = @Date, [Description] = @Description WHERE (([EmployeeIncidentID] = @Original_EmployeeIncidentID) AND ((@IsNull_EmployeeID = 1 AND [EmployeeID] IS NULL) OR ([EmployeeID] = @Original_EmployeeID)) AND ((@IsNull_Date = 1 AND [Date] IS NULL) OR ([Date] = @Original_Date)) AND ((@IsNull_Description = 1 AND [Description] IS NULL) OR ([Description] = @Original_Description)));
	
SELECT EmployeeIncidentID, EmployeeID, Date, Description FROM EmployeeIncident WHERE (EmployeeIncidentID = @EmployeeIncidentID)
go

