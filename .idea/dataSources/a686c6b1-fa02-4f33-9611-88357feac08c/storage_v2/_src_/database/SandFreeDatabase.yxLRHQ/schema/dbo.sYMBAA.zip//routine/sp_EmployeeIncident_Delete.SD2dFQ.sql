
CREATE PROCEDURE [dbo].[sp_EmployeeIncident_Delete]
(
	@Original_EmployeeIncidentID int,
	@IsNull_EmployeeID Int,
	@Original_EmployeeID int,
	@IsNull_Date Int,
	@Original_Date datetime,
	@IsNull_Description Int,
	@Original_Description varchar(255)
)
AS
	SET NOCOUNT OFF;
DELETE FROM [EmployeeIncident] WHERE (([EmployeeIncidentID] = @Original_EmployeeIncidentID) AND ((@IsNull_EmployeeID = 1 AND [EmployeeID] IS NULL) OR ([EmployeeID] = @Original_EmployeeID)) AND ((@IsNull_Date = 1 AND [Date] IS NULL) OR ([Date] = @Original_Date)) AND ((@IsNull_Description = 1 AND [Description] IS NULL) OR ([Description] = @Original_Description)))
go

