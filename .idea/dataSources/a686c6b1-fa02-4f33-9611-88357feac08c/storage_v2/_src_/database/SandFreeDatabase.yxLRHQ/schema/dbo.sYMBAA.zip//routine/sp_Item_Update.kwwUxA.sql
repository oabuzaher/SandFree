
CREATE PROCEDURE [dbo].sp_Item_Update
(
	@ItemListID int,
	@ServiceID int,
	@WarehouseID int,
	@Name varchar(50),
	@Quantity int,
	@Price decimal(9, 2),
	@Description varchar(255),
	@Original_ItemID int,
	@IsNull_ItemListID Int,
	@Original_ItemListID int,
	@IsNull_ServiceID Int,
	@Original_ServiceID int,
	@IsNull_WarehouseID Int,
	@Original_WarehouseID int,
	@IsNull_Name Int,
	@Original_Name varchar(50),
	@IsNull_Quantity Int,
	@Original_Quantity int,
	@IsNull_Price Int,
	@Original_Price decimal(9, 2),
	@IsNull_Description Int,
	@Original_Description varchar(255),
	@ItemID int
)
AS
	SET NOCOUNT OFF;
UPDATE [Item] SET [ItemListID] = @ItemListID, [ServiceID] = @ServiceID, [WarehouseID] = @WarehouseID, [Name] = @Name, [Quantity] = @Quantity, [Price] = @Price, [Description] = @Description WHERE (([ItemID] = @Original_ItemID) AND ((@IsNull_ItemListID = 1 AND [ItemListID] IS NULL) OR ([ItemListID] = @Original_ItemListID)) AND ((@IsNull_ServiceID = 1 AND [ServiceID] IS NULL) OR ([ServiceID] = @Original_ServiceID)) AND ((@IsNull_WarehouseID = 1 AND [WarehouseID] IS NULL) OR ([WarehouseID] = @Original_WarehouseID)) AND ((@IsNull_Name = 1 AND [Name] IS NULL) OR ([Name] = @Original_Name)) AND ((@IsNull_Quantity = 1 AND [Quantity] IS NULL) OR ([Quantity] = @Original_Quantity)) AND ((@IsNull_Price = 1 AND [Price] IS NULL) OR ([Price] = @Original_Price)) AND ((@IsNull_Description = 1 AND [Description] IS NULL) OR ([Description] = @Original_Description)));
	
SELECT ItemID, ItemListID, ServiceID, WarehouseID, Name, Quantity, Price, Description FROM Item WHERE (ItemID = @ItemID)
go

