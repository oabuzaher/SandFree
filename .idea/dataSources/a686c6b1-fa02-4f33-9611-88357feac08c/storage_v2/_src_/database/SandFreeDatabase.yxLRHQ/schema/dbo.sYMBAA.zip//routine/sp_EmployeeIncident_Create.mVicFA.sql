
CREATE PROCEDURE [dbo].[sp_EmployeeIncident_Create]
(
	@EmployeeID int,
	@Date datetime,
	@Description varchar(255)
)
AS
	SET NOCOUNT OFF;
INSERT INTO [EmployeeIncident] ([EmployeeID], [Date], [Description]) VALUES (@EmployeeID, @Date, @Description);
	
SELECT EmployeeIncidentID, EmployeeID, Date, Description FROM EmployeeIncident WHERE (EmployeeIncidentID = SCOPE_IDENTITY())
go

