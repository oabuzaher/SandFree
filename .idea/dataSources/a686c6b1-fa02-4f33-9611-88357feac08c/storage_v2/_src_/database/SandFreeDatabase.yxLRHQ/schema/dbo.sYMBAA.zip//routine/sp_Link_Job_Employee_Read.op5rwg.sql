
CREATE PROCEDURE [dbo].sp_Link_Job_Employee_Read
AS
	SET NOCOUNT ON;
SELECT Link_Job_Employee.*
FROM Link_Job_Employee
go

