
CREATE PROCEDURE [dbo].[sp_EmployeeIncident_Read]
AS
	SET NOCOUNT ON;
SELECT EmployeeIncident.*
FROM EmployeeIncident
go

