
CREATE PROCEDURE [dbo].sp_ServiceList_Read
AS
	SET NOCOUNT ON;
SELECT ServiceList.*
FROM ServiceList

go

