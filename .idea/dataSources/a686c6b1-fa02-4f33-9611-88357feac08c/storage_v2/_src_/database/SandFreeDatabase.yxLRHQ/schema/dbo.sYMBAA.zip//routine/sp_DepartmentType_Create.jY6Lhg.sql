
CREATE PROCEDURE [dbo].sp_DepartmentType_Create
(
	@Type varchar(50)
)
AS
	SET NOCOUNT OFF;
INSERT INTO [DepartmentType] ([Type]) VALUES (@Type);
	
SELECT DepartmentTypeID, Type FROM DepartmentType WHERE (DepartmentTypeID = SCOPE_IDENTITY())
go

