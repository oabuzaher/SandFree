
CREATE PROCEDURE [dbo].sp_Service_Create
(
	@JobID int,
	@Description varchar(255),
	@Name varchar(50)
)
AS
	SET NOCOUNT OFF;
INSERT INTO [Service] ([JobID], [Description], [Name]) VALUES (@JobID, @Description, @Name);
	
SELECT ServiceID, JobID, Description, Name FROM Service WHERE (ServiceID = SCOPE_IDENTITY())
go

