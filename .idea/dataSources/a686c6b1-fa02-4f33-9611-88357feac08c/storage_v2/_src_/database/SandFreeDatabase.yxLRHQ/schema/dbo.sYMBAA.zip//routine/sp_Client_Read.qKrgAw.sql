
CREATE PROCEDURE [dbo].sp_Client_Read
AS
	SET NOCOUNT ON;
SELECT Client.*
FROM Client

go

