
CREATE PROCEDURE [dbo].sp_Job_Create
(
	@ClientID int,
	@CreationDate datetime,
	@CompletionDate datetime,
	@LaborHours int,
	@Complete bit,
	@Description varchar(255)
)
AS
	SET NOCOUNT OFF;
INSERT INTO [Job] ([ClientID], [CreationDate], [CompletionDate], [LaborHours], [Complete], [Description]) VALUES (@ClientID, @CreationDate, @CompletionDate, @LaborHours, @Complete, @Description);
	
SELECT JobID, ClientID, CreationDate, CompletionDate, LaborHours, Complete, Description FROM Job WHERE (JobID = SCOPE_IDENTITY())
go

