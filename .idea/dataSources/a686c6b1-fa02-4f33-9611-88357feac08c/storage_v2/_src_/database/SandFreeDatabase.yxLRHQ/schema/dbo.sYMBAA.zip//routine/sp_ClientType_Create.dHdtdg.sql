
CREATE PROCEDURE [dbo].sp_ClientType_Create
(
	@Type varchar(50)
)
AS
	SET NOCOUNT OFF;
INSERT INTO [ClientType] ([Type]) VALUES (@Type);
	
SELECT ClientTypeID, Type FROM ClientType WHERE (ClientTypeID = SCOPE_IDENTITY())
go

