Create Function dbo.ufnItemList(@itemlistID  int) 
RETURNS int
as
begin

return @itemlistID
end ;
go

