
CREATE PROCEDURE [dbo].sp_Client_Create
(
	@HomePhone varchar(20),
	@WorkPhone varchar(20),
	@Email varchar(100),
	@Address varchar(100),
	@City varchar(50),
	@StateProvinceCode varchar(20),
	@PostalCode int,
	@FirstName varchar(50),
	@LastName varchar(50),
	@ClientType varchar(50)
)
AS
	SET NOCOUNT OFF;
INSERT INTO [Client] ([HomePhone], [WorkPhone], [Email], [Address], [City], [StateProvinceCode], [PostalCode], [FirstName], [LastName], [ClientType]) VALUES (@HomePhone, @WorkPhone, @Email, @Address, @City, @StateProvinceCode, @PostalCode, @FirstName, @LastName, @ClientType);
	
SELECT ClientID, HomePhone, WorkPhone, Email, Address, City, StateProvinceCode, PostalCode, FirstName, LastName, ClientType FROM Client WHERE (ClientID = SCOPE_IDENTITY())
go

