
CREATE PROCEDURE [dbo].sp_DepartmentType_Read
AS
	SET NOCOUNT ON;
SELECT DepartmentType.*
FROM DepartmentType
go

