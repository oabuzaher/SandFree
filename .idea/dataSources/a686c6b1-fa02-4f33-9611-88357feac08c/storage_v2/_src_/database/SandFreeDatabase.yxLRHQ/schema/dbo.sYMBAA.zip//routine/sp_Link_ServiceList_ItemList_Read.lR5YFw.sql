
CREATE PROCEDURE [dbo].sp_Link_ServiceList_ItemList_Read
AS
	SET NOCOUNT ON;
SELECT Link_ServiceList_ItemList.*
FROM Link_ServiceList_ItemList
go

