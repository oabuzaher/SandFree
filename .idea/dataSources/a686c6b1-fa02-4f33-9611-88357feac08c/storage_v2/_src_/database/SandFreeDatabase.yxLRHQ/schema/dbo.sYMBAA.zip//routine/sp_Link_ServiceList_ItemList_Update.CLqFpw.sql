
CREATE PROCEDURE [dbo].sp_Link_ServiceList_ItemList_Update
(
	@ServiceListID int,
	@ItemListID int,
	@Original_ServiceListID int,
	@Original_ItemListID int
)
AS
	SET NOCOUNT OFF;
UPDATE [Link_ServiceList_ItemList] SET [ServiceListID] = @ServiceListID, [ItemListID] = @ItemListID WHERE (([ServiceListID] = @Original_ServiceListID) AND ([ItemListID] = @Original_ItemListID));
	
SELECT ServiceListID, ItemListID FROM Link_ServiceList_ItemList WHERE (ItemListID = @ItemListID) AND (ServiceListID = @ServiceListID)
go

