
CREATE PROCEDURE [dbo].sp_Warehouse_Read
AS
	SET NOCOUNT ON;
SELECT Warehouse.*
FROM Warehouse
go

