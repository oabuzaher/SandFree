
CREATE PROCEDURE [dbo].sp_Inventory_Delete
(
	@Original_WarehouseID int,
	@Original_ItemListID int,
	@IsNull_Quantity Int,
	@Original_Quantity int,
	@IsNull_Units Int,
	@Original_Units varchar(50)
)
AS
	SET NOCOUNT OFF;
DELETE FROM [Inventory] WHERE (([WarehouseID] = @Original_WarehouseID) AND ([ItemListID] = @Original_ItemListID) AND ((@IsNull_Quantity = 1 AND [Quantity] IS NULL) OR ([Quantity] = @Original_Quantity)) AND ((@IsNull_Units = 1 AND [Units] IS NULL) OR ([Units] = @Original_Units)))
go

