
CREATE PROCEDURE [dbo].sp_ServiceList_Delete
(
	@Original_ServiceListID int,
	@IsNull_Name Int,
	@Original_Name varchar(50),
	@IsNull_Description Int,
	@Original_Description varchar(255),
	@IsNull_Price Int,
	@Original_Price decimal(9, 2)
)
AS
	SET NOCOUNT OFF;
DELETE FROM [ServiceList] WHERE (([ServiceListID] = @Original_ServiceListID) AND ((@IsNull_Name = 1 AND [Name] IS NULL) OR ([Name] = @Original_Name)) AND ((@IsNull_Description = 1 AND [Description] IS NULL) OR ([Description] = @Original_Description)) AND ((@IsNull_Price = 1 AND [Price] IS NULL) OR ([Price] = @Original_Price)))
go

