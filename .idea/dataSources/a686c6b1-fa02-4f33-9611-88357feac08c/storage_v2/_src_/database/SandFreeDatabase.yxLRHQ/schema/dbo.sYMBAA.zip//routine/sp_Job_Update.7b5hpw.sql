
CREATE PROCEDURE [dbo].sp_Job_Update
(
	@ClientID int,
	@CreationDate datetime,
	@CompletionDate datetime,
	@LaborHours int,
	@Complete bit,
	@Description varchar(255),
	@Original_JobID int,
	@IsNull_ClientID Int,
	@Original_ClientID int,
	@IsNull_CreationDate Int,
	@Original_CreationDate datetime,
	@IsNull_CompletionDate Int,
	@Original_CompletionDate datetime,
	@IsNull_LaborHours Int,
	@Original_LaborHours int,
	@Original_Complete bit,
	@IsNull_Description Int,
	@Original_Description varchar(255),
	@JobID int
)
AS
	SET NOCOUNT OFF;
UPDATE [Job] SET [ClientID] = @ClientID, [CreationDate] = @CreationDate, [CompletionDate] = @CompletionDate, [LaborHours] = @LaborHours, [Complete] = @Complete, [Description] = @Description WHERE (([JobID] = @Original_JobID) AND ((@IsNull_ClientID = 1 AND [ClientID] IS NULL) OR ([ClientID] = @Original_ClientID)) AND ((@IsNull_CreationDate = 1 AND [CreationDate] IS NULL) OR ([CreationDate] = @Original_CreationDate)) AND ((@IsNull_CompletionDate = 1 AND [CompletionDate] IS NULL) OR ([CompletionDate] = @Original_CompletionDate)) AND ((@IsNull_LaborHours = 1 AND [LaborHours] IS NULL) OR ([LaborHours] = @Original_LaborHours)) AND ([Complete] = @Original_Complete) AND ((@IsNull_Description = 1 AND [Description] IS NULL) OR ([Description] = @Original_Description)));
	
SELECT JobID, ClientID, CreationDate, CompletionDate, LaborHours, Complete, Description FROM Job WHERE (JobID = @JobID)
go

