
CREATE PROCEDURE [dbo].sp_Inventory_Read
AS
	SET NOCOUNT ON;
SELECT Inventory.*
FROM Inventory
go

