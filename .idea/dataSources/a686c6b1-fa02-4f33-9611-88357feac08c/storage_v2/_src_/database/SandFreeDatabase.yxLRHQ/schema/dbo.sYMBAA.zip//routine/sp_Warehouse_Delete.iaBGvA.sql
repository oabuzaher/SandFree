
CREATE PROCEDURE [dbo].sp_Warehouse_Delete
(
	@Original_WarehouseID int,
	@IsNull_Name Int,
	@Original_Name varchar(50),
	@IsNull_Address Int,
	@Original_Address varchar(100),
	@IsNull_City Int,
	@Original_City varchar(50),
	@IsNull_StateProvinceCode Int,
	@Original_StateProvinceCode varchar(20),
	@IsNull_PostalCode Int,
	@Original_PostalCode int,
	@Original_IsActive bit
)
AS
	SET NOCOUNT OFF;
DELETE FROM [Warehouse] WHERE (([WarehouseID] = @Original_WarehouseID) AND ((@IsNull_Name = 1 AND [Name] IS NULL) OR ([Name] = @Original_Name)) AND ((@IsNull_Address = 1 AND [Address] IS NULL) OR ([Address] = @Original_Address)) AND ((@IsNull_City = 1 AND [City] IS NULL) OR ([City] = @Original_City)) AND ((@IsNull_StateProvinceCode = 1 AND [StateProvinceCode] IS NULL) OR ([StateProvinceCode] = @Original_StateProvinceCode)) AND ((@IsNull_PostalCode = 1 AND [PostalCode] IS NULL) OR ([PostalCode] = @Original_PostalCode)) AND ([IsActive] = @Original_IsActive))
go

