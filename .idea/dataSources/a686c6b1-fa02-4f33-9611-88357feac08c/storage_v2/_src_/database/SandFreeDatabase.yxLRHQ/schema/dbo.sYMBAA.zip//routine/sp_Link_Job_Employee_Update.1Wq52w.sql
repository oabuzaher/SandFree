
CREATE PROCEDURE [dbo].sp_Link_Job_Employee_Update
(
	@JobID int,
	@EmployeeID int,
	@Original_JobID int,
	@Original_EmployeeID int
)
AS
	SET NOCOUNT OFF;
UPDATE [Link_Job_Employee] SET [JobID] = @JobID, [EmployeeID] = @EmployeeID WHERE (([JobID] = @Original_JobID) AND ([EmployeeID] = @Original_EmployeeID));
	
SELECT JobID, EmployeeID FROM Link_Job_Employee WHERE (EmployeeID = @EmployeeID) AND (JobID = @JobID)
go

