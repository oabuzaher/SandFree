
CREATE PROCEDURE [dbo].sp_Job_Delete
(
	@Original_JobID int,
	@IsNull_ClientID Int,
	@Original_ClientID int,
	@IsNull_CreationDate Int,
	@Original_CreationDate datetime,
	@IsNull_CompletionDate Int,
	@Original_CompletionDate datetime,
	@IsNull_LaborHours Int,
	@Original_LaborHours int,
	@Original_Complete bit,
	@IsNull_Description Int,
	@Original_Description varchar(255)
)
AS
	SET NOCOUNT OFF;
DELETE FROM [Job] WHERE (([JobID] = @Original_JobID) AND ((@IsNull_ClientID = 1 AND [ClientID] IS NULL) OR ([ClientID] = @Original_ClientID)) AND ((@IsNull_CreationDate = 1 AND [CreationDate] IS NULL) OR ([CreationDate] = @Original_CreationDate)) AND ((@IsNull_CompletionDate = 1 AND [CompletionDate] IS NULL) OR ([CompletionDate] = @Original_CompletionDate)) AND ((@IsNull_LaborHours = 1 AND [LaborHours] IS NULL) OR ([LaborHours] = @Original_LaborHours)) AND ([Complete] = @Original_Complete) AND ((@IsNull_Description = 1 AND [Description] IS NULL) OR ([Description] = @Original_Description)))
go

