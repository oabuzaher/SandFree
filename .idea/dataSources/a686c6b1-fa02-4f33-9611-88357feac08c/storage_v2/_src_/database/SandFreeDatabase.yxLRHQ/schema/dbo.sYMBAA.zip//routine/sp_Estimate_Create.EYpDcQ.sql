
CREATE PROCEDURE [dbo].sp_Estimate_Create
(
	@JobID int,
	@Price decimal(9, 2),
	@IsApproved bit,
	@HoursRequired int,
	@Date datetime,
	@PreparedBy varchar(50),
	@ValidUntil datetime,
	@Description varchar(255)
)
AS
	SET NOCOUNT OFF;
INSERT INTO [Estimate] ([JobID], [Price], [IsApproved], [HoursRequired], [Date], [PreparedBy], [ValidUntil], [Description]) VALUES (@JobID, @Price, @IsApproved, @HoursRequired, @Date, @PreparedBy, @ValidUntil, @Description);
	
SELECT EstimateID, JobID, Price, IsApproved, HoursRequired, Date, PreparedBy, ValidUntil, Description FROM Estimate WHERE (EstimateID = SCOPE_IDENTITY())
go

