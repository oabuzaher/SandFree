
CREATE PROCEDURE [dbo].sp_ClientType_Delete
(
	@Original_ClientTypeID int,
	@IsNull_Type Int,
	@Original_Type varchar(50)
)
AS
	SET NOCOUNT OFF;
DELETE FROM [ClientType] WHERE (([ClientTypeID] = @Original_ClientTypeID) AND ((@IsNull_Type = 1 AND [Type] IS NULL) OR ([Type] = @Original_Type)))
go

