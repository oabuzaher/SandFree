
CREATE PROCEDURE [dbo].sp_Link_Job_Employee_Create
(
	@JobID int,
	@EmployeeID int
)
AS
	SET NOCOUNT OFF;
INSERT INTO [Link_Job_Employee] ([JobID], [EmployeeID]) VALUES (@JobID, @EmployeeID);
	
SELECT JobID, EmployeeID FROM Link_Job_Employee WHERE (EmployeeID = @EmployeeID) AND (JobID = @JobID)
go

