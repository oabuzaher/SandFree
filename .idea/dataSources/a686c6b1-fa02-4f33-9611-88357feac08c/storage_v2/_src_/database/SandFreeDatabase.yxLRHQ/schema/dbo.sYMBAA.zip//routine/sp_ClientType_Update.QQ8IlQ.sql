
CREATE PROCEDURE [dbo].sp_ClientType_Update
(
	@Type varchar(50),
	@Original_ClientTypeID int,
	@IsNull_Type Int,
	@Original_Type varchar(50),
	@ClientTypeID int
)
AS
	SET NOCOUNT OFF;
UPDATE [ClientType] SET [Type] = @Type WHERE (([ClientTypeID] = @Original_ClientTypeID) AND ((@IsNull_Type = 1 AND [Type] IS NULL) OR ([Type] = @Original_Type)));
	
SELECT ClientTypeID, Type FROM ClientType WHERE (ClientTypeID = @ClientTypeID)
go

