
CREATE PROCEDURE [dbo].sp_Warehouse_Create
(
	@Name varchar(50),
	@Address varchar(100),
	@City varchar(50),
	@StateProvinceCode varchar(20),
	@PostalCode int,
	@IsActive bit
)
AS
	SET NOCOUNT OFF;
INSERT INTO [Warehouse] ([Name], [Address], [City], [StateProvinceCode], [PostalCode], [IsActive]) VALUES (@Name, @Address, @City, @StateProvinceCode, @PostalCode, @IsActive);
	
SELECT WarehouseID, Name, Address, City, StateProvinceCode, PostalCode, IsActive FROM Warehouse WHERE (WarehouseID = SCOPE_IDENTITY())
go

