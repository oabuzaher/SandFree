
CREATE PROCEDURE [dbo].sp_ItemList_Read
AS
	SET NOCOUNT ON;
SELECT ItemList.*
FROM ItemList
go

