
CREATE PROCEDURE [dbo].sp_DepartmentType_Delete
(
	@Original_DepartmentTypeID int,
	@IsNull_Type Int,
	@Original_Type varchar(50)
)
AS
	SET NOCOUNT OFF;
DELETE FROM [DepartmentType] WHERE (([DepartmentTypeID] = @Original_DepartmentTypeID) AND ((@IsNull_Type = 1 AND [Type] IS NULL) OR ([Type] = @Original_Type)))
go

