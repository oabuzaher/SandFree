
CREATE PROCEDURE [dbo].sp_ItemList_Create
(
	@Name varchar(50),
	@Price decimal(9, 2),
	@Description varchar(255)
)
AS
	SET NOCOUNT OFF;
INSERT INTO [ItemList] ([Name], [Price], [Description]) VALUES (@Name, @Price, @Description);
	
SELECT ItemListID, Name, Price, Description FROM ItemList WHERE (ItemListID = SCOPE_IDENTITY())
go

