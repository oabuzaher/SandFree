
CREATE PROCEDURE [dbo].sp_DepartmentType_Update
(
	@Type varchar(50),
	@Original_DepartmentTypeID int,
	@IsNull_Type Int,
	@Original_Type varchar(50),
	@DepartmentTypeID int
)
AS
	SET NOCOUNT OFF;
UPDATE [DepartmentType] SET [Type] = @Type WHERE (([DepartmentTypeID] = @Original_DepartmentTypeID) AND ((@IsNull_Type = 1 AND [Type] IS NULL) OR ([Type] = @Original_Type)));
	
SELECT DepartmentTypeID, Type FROM DepartmentType WHERE (DepartmentTypeID = @DepartmentTypeID)
go

