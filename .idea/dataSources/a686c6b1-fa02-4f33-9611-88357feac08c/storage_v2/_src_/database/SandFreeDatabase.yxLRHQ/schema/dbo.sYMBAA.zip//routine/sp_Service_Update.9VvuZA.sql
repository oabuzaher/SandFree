
CREATE PROCEDURE [dbo].sp_Service_Update
(
	@JobID int,
	@Description varchar(255),
	@Name varchar(50),
	@Original_ServiceID int,
	@IsNull_JobID Int,
	@Original_JobID int,
	@IsNull_Description Int,
	@Original_Description varchar(255),
	@IsNull_Name Int,
	@Original_Name varchar(50),
	@ServiceID int
)
AS
	SET NOCOUNT OFF;
UPDATE [Service] SET [JobID] = @JobID, [Description] = @Description, [Name] = @Name WHERE (([ServiceID] = @Original_ServiceID) AND ((@IsNull_JobID = 1 AND [JobID] IS NULL) OR ([JobID] = @Original_JobID)) AND ((@IsNull_Description = 1 AND [Description] IS NULL) OR ([Description] = @Original_Description)) AND ((@IsNull_Name = 1 AND [Name] IS NULL) OR ([Name] = @Original_Name)));
	
SELECT ServiceID, JobID, Description, Name FROM Service WHERE (ServiceID = @ServiceID)
go

