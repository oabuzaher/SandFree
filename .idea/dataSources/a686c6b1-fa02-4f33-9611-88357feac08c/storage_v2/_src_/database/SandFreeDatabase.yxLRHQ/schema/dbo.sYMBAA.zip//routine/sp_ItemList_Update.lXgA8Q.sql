
CREATE PROCEDURE [dbo].sp_ItemList_Update
(
	@Name varchar(50),
	@Price decimal(9, 2),
	@Description varchar(255),
	@Original_ItemListID int,
	@IsNull_Name Int,
	@Original_Name varchar(50),
	@IsNull_Price Int,
	@Original_Price decimal(9, 2),
	@IsNull_Description Int,
	@Original_Description varchar(255),
	@ItemListID int
)
AS
	SET NOCOUNT OFF;
UPDATE [ItemList] SET [Name] = @Name, [Price] = @Price, [Description] = @Description WHERE (([ItemListID] = @Original_ItemListID) AND ((@IsNull_Name = 1 AND [Name] IS NULL) OR ([Name] = @Original_Name)) AND ((@IsNull_Price = 1 AND [Price] IS NULL) OR ([Price] = @Original_Price)) AND ((@IsNull_Description = 1 AND [Description] IS NULL) OR ([Description] = @Original_Description)));
	
SELECT ItemListID, Name, Price, Description FROM ItemList WHERE (ItemListID = @ItemListID)
go

