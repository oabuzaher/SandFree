
CREATE PROCEDURE [dbo].sp_Service_Read
AS
	SET NOCOUNT ON;
SELECT Service.*
FROM Service
go

