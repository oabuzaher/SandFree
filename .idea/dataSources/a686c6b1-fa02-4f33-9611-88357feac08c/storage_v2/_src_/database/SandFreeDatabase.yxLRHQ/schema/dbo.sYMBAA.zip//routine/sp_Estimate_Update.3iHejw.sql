
CREATE PROCEDURE [dbo].sp_Estimate_Update
(
	@JobID int,
	@Price decimal(9, 2),
	@IsApproved bit,
	@HoursRequired int,
	@Date datetime,
	@PreparedBy varchar(50),
	@ValidUntil datetime,
	@Description varchar(255),
	@Original_EstimateID int,
	@IsNull_JobID Int,
	@Original_JobID int,
	@IsNull_Price Int,
	@Original_Price decimal(9, 2),
	@Original_IsApproved bit,
	@IsNull_HoursRequired Int,
	@Original_HoursRequired int,
	@IsNull_Date Int,
	@Original_Date datetime,
	@IsNull_PreparedBy Int,
	@Original_PreparedBy varchar(50),
	@IsNull_ValidUntil Int,
	@Original_ValidUntil datetime,
	@IsNull_Description Int,
	@Original_Description varchar(255),
	@EstimateID int
)
AS
	SET NOCOUNT OFF;
UPDATE [Estimate] SET [JobID] = @JobID, [Price] = @Price, [IsApproved] = @IsApproved, [HoursRequired] = @HoursRequired, [Date] = @Date, [PreparedBy] = @PreparedBy, [ValidUntil] = @ValidUntil, [Description] = @Description WHERE (([EstimateID] = @Original_EstimateID) AND ((@IsNull_JobID = 1 AND [JobID] IS NULL) OR ([JobID] = @Original_JobID)) AND ((@IsNull_Price = 1 AND [Price] IS NULL) OR ([Price] = @Original_Price)) AND ([IsApproved] = @Original_IsApproved) AND ((@IsNull_HoursRequired = 1 AND [HoursRequired] IS NULL) OR ([HoursRequired] = @Original_HoursRequired)) AND ((@IsNull_Date = 1 AND [Date] IS NULL) OR ([Date] = @Original_Date)) AND ((@IsNull_PreparedBy = 1 AND [PreparedBy] IS NULL) OR ([PreparedBy] = @Original_PreparedBy)) AND ((@IsNull_ValidUntil = 1 AND [ValidUntil] IS NULL) OR ([ValidUntil] = @Original_ValidUntil)) AND ((@IsNull_Description = 1 AND [Description] IS NULL) OR ([Description] = @Original_Description)));
	
SELECT EstimateID, JobID, Price, IsApproved, HoursRequired, Date, PreparedBy, ValidUntil, Description FROM Estimate WHERE (EstimateID = @EstimateID)
go

