
CREATE PROCEDURE [dbo].sp_Link_ServiceList_ItemList_Delete
(
	@Original_ServiceListID int,
	@Original_ItemListID int
)
AS
	SET NOCOUNT OFF;
DELETE FROM [Link_ServiceList_ItemList] WHERE (([ServiceListID] = @Original_ServiceListID) AND ([ItemListID] = @Original_ItemListID))
go

