CREATE VIEW dbo.DepartmentEmployeeList
AS 
select (e.firstname + ' ' + e.lastname) as EmployeeName, e.Address, e.City, 
d.type as DepartmentType
from employee e
INNER JOIN departmenttype d ON e.[DepartmentTypeID] = d.[DepartmentTypeID]
go

