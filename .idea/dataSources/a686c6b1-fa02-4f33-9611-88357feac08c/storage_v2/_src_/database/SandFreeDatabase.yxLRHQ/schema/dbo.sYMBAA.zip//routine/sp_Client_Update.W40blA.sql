
CREATE PROCEDURE [dbo].sp_Client_Update
(
	@HomePhone varchar(20),
	@WorkPhone varchar(20),
	@Email varchar(100),
	@Address varchar(100),
	@City varchar(50),
	@StateProvinceCode varchar(20),
	@PostalCode int,
	@FirstName varchar(50),
	@LastName varchar(50),
	@ClientType varchar(50),
	@Original_ClientID int,
	@IsNull_HomePhone Int,
	@Original_HomePhone varchar(20),
	@IsNull_WorkPhone Int,
	@Original_WorkPhone varchar(20),
	@IsNull_Email Int,
	@Original_Email varchar(100),
	@IsNull_Address Int,
	@Original_Address varchar(100),
	@IsNull_City Int,
	@Original_City varchar(50),
	@IsNull_StateProvinceCode Int,
	@Original_StateProvinceCode varchar(20),
	@IsNull_PostalCode Int,
	@Original_PostalCode int,
	@IsNull_FirstName Int,
	@Original_FirstName varchar(50),
	@IsNull_LastName Int,
	@Original_LastName varchar(50),
	@IsNull_ClientType Int,
	@Original_ClientType varchar(50),
	@ClientID int
)
AS
	SET NOCOUNT OFF;
UPDATE [Client] SET [HomePhone] = @HomePhone, [WorkPhone] = @WorkPhone, [Email] = @Email, [Address] = @Address, [City] = @City, [StateProvinceCode] = @StateProvinceCode, [PostalCode] = @PostalCode, [FirstName] = @FirstName, [LastName] = @LastName, [ClientType] = @ClientType WHERE (([ClientID] = @Original_ClientID) AND ((@IsNull_HomePhone = 1 AND [HomePhone] IS NULL) OR ([HomePhone] = @Original_HomePhone)) AND ((@IsNull_WorkPhone = 1 AND [WorkPhone] IS NULL) OR ([WorkPhone] = @Original_WorkPhone)) AND ((@IsNull_Email = 1 AND [Email] IS NULL) OR ([Email] = @Original_Email)) AND ((@IsNull_Address = 1 AND [Address] IS NULL) OR ([Address] = @Original_Address)) AND ((@IsNull_City = 1 AND [City] IS NULL) OR ([City] = @Original_City)) AND ((@IsNull_StateProvinceCode = 1 AND [StateProvinceCode] IS NULL) OR ([StateProvinceCode] = @Original_StateProvinceCode)) AND ((@IsNull_PostalCode = 1 AND [PostalCode] IS NULL) OR ([PostalCode] = @Original_PostalCode)) AND ((@IsNull_FirstName = 1 AND [FirstName] IS NULL) OR ([FirstName] = @Original_FirstName)) AND ((@IsNull_LastName = 1 AND [LastName] IS NULL) OR ([LastName] = @Original_LastName)) AND ((@IsNull_ClientType = 1 AND [ClientType] IS NULL) OR ([ClientType] = @Original_ClientType)));
	
SELECT ClientID, HomePhone, WorkPhone, Email, Address, City, StateProvinceCode, PostalCode, FirstName, LastName, ClientType FROM Client WHERE (ClientID = @ClientID)
go

