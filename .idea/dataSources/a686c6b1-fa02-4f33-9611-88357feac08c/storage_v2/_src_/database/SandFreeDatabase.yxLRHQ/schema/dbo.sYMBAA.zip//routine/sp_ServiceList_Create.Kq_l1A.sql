
CREATE PROCEDURE [dbo].sp_ServiceList_Create
(
	@Name varchar(50),
	@Description varchar(255),
	@Price decimal(9, 2)
)
AS
	SET NOCOUNT OFF;
INSERT INTO [ServiceList] ([Name], [Description], [Price]) VALUES (@Name, @Description, @Price);
	
SELECT ServiceListID, Name, Description, Price FROM ServiceList WHERE (ServiceListID = SCOPE_IDENTITY())
go

