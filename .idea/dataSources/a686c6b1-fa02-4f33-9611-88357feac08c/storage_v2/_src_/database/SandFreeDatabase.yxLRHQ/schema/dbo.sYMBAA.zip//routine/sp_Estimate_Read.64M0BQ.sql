
CREATE PROCEDURE [dbo].sp_Estimate_Read
AS
	SET NOCOUNT ON;
SELECT Estimate.*
FROM Estimate
go

