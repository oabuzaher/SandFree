
CREATE PROCEDURE [dbo].sp_Item_Create
(
	@ItemListID int,
	@ServiceID int,
	@WarehouseID int,
	@Name varchar(50),
	@Quantity int,
	@Price decimal(9, 2),
	@Description varchar(255)
)
AS
	SET NOCOUNT OFF;
INSERT INTO [Item] ([ItemListID], [ServiceID], [WarehouseID], [Name], [Quantity], [Price], [Description]) VALUES (@ItemListID, @ServiceID, @WarehouseID, @Name, @Quantity, @Price, @Description);
	
SELECT ItemID, ItemListID, ServiceID, WarehouseID, Name, Quantity, Price, Description FROM Item WHERE (ItemID = SCOPE_IDENTITY())
go

