
CREATE PROCEDURE [dbo].sp_Inventory_Create
(
	@WarehouseID int,
	@ItemListID int,
	@Quantity int,
	@Units varchar(50)
)
AS
	SET NOCOUNT OFF;
INSERT INTO [Inventory] ([WarehouseID], [ItemListID], [Quantity], [Units]) VALUES (@WarehouseID, @ItemListID, @Quantity, @Units);
	
SELECT WarehouseID, ItemListID, Quantity, Units FROM Inventory WHERE (ItemListID = @ItemListID) AND (WarehouseID = @WarehouseID)
go

