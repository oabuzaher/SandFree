
CREATE PROCEDURE [dbo].sp_Link_Job_Employee_Delete
(
	@Original_JobID int,
	@Original_EmployeeID int
)
AS
	SET NOCOUNT OFF;
DELETE FROM [Link_Job_Employee] WHERE (([JobID] = @Original_JobID) AND ([EmployeeID] = @Original_EmployeeID))
go

