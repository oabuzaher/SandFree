CREATE TRIGGER EmployeeTrigger
on Employee
after update,insert
as 
begin 
print 'This employee has been updated or inserted.'
end
go

