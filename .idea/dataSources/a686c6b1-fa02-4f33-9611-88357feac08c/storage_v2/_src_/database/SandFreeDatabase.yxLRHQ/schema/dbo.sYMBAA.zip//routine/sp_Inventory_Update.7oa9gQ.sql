
CREATE PROCEDURE [dbo].sp_Inventory_Update
(
	@WarehouseID int,
	@ItemListID int,
	@Quantity int,
	@Units varchar(50),
	@Original_WarehouseID int,
	@Original_ItemListID int,
	@IsNull_Quantity Int,
	@Original_Quantity int,
	@IsNull_Units Int,
	@Original_Units varchar(50)
)
AS
	SET NOCOUNT OFF;
UPDATE [Inventory] SET [WarehouseID] = @WarehouseID, [ItemListID] = @ItemListID, [Quantity] = @Quantity, [Units] = @Units WHERE (([WarehouseID] = @Original_WarehouseID) AND ([ItemListID] = @Original_ItemListID) AND ((@IsNull_Quantity = 1 AND [Quantity] IS NULL) OR ([Quantity] = @Original_Quantity)) AND ((@IsNull_Units = 1 AND [Units] IS NULL) OR ([Units] = @Original_Units)));
	
SELECT WarehouseID, ItemListID, Quantity, Units FROM Inventory WHERE (ItemListID = @ItemListID) AND (WarehouseID = @WarehouseID)
go

