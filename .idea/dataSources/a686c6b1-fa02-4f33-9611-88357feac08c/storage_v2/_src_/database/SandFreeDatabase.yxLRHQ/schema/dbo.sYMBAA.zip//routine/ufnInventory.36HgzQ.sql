CREATE FUNCTION dbo.ufnInventory(@itemlistID int)
Returns int
as 
begin 
return @itemlistid
end;
go

