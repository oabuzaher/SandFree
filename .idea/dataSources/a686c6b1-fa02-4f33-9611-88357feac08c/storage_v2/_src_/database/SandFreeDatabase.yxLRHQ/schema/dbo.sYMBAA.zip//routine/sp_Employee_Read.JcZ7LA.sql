
CREATE PROCEDURE [dbo].sp_Employee_Read
AS
	SET NOCOUNT ON;
SELECT Employee.*
FROM Employee
go

