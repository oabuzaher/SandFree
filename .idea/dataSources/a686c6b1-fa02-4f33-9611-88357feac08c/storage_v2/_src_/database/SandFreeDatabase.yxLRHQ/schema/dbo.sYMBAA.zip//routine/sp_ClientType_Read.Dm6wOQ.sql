
CREATE PROCEDURE [dbo].sp_ClientType_Read
AS
	SET NOCOUNT ON;
SELECT ClientType.*
FROM ClientType
go

