
CREATE PROCEDURE [dbo].sp_Employee_Create
(
	@IsAdmin bit,
	@Password varchar(50),
	@FirstName varchar(50),
	@LastName varchar(50),
	@HomePhone varchar(20),
	@Email varchar(100),
	@Address varchar(100),
	@City varchar(50),
	@StateProvinceCode varchar(20),
	@PostalCode int,
	@IsEnabled bit,
	@DepartmentTypeID int
)
AS
	SET NOCOUNT OFF;
INSERT INTO [Employee] ([IsAdmin], [Password], [FirstName], [LastName], [HomePhone], [Email], [Address], [City], [StateProvinceCode], [PostalCode], [IsEnabled], [DepartmentTypeID]) VALUES (@IsAdmin, @Password, @FirstName, @LastName, @HomePhone, @Email, @Address, @City, @StateProvinceCode, @PostalCode, @IsEnabled, @DepartmentTypeID);
	
SELECT EmployeeID, IsAdmin, Password, FirstName, LastName, HomePhone, Email, Address, City, StateProvinceCode, PostalCode, IsEnabled, DepartmentTypeID FROM Employee WHERE (EmployeeID = SCOPE_IDENTITY())
go

