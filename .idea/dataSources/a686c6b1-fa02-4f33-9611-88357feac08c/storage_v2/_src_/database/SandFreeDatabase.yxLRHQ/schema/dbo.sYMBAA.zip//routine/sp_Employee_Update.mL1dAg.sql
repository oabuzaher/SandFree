
CREATE PROCEDURE [dbo].sp_Employee_Update
(
	@IsAdmin bit,
	@Password varchar(50),
	@FirstName varchar(50),
	@LastName varchar(50),
	@HomePhone varchar(20),
	@Email varchar(100),
	@Address varchar(100),
	@City varchar(50),
	@StateProvinceCode varchar(20),
	@PostalCode int,
	@IsEnabled bit,
	@DepartmentTypeID int,
	@Original_EmployeeID int,
	@Original_IsAdmin bit,
	@IsNull_Password Int,
	@Original_Password varchar(50),
	@IsNull_FirstName Int,
	@Original_FirstName varchar(50),
	@IsNull_LastName Int,
	@Original_LastName varchar(50),
	@IsNull_HomePhone Int,
	@Original_HomePhone varchar(20),
	@IsNull_Email Int,
	@Original_Email varchar(100),
	@IsNull_Address Int,
	@Original_Address varchar(100),
	@IsNull_City Int,
	@Original_City varchar(50),
	@IsNull_StateProvinceCode Int,
	@Original_StateProvinceCode varchar(20),
	@IsNull_PostalCode Int,
	@Original_PostalCode int,
	@Original_IsEnabled bit,
	@IsNull_DepartmentTypeID Int,
	@Original_DepartmentTypeID int,
	@EmployeeID int
)
AS
	SET NOCOUNT OFF;
UPDATE [Employee] SET [IsAdmin] = @IsAdmin, [Password] = @Password, [FirstName] = @FirstName, [LastName] = @LastName, [HomePhone] = @HomePhone, [Email] = @Email, [Address] = @Address, [City] = @City, [StateProvinceCode] = @StateProvinceCode, [PostalCode] = @PostalCode, [IsEnabled] = @IsEnabled, [DepartmentTypeID] = @DepartmentTypeID WHERE (([EmployeeID] = @Original_EmployeeID) AND ([IsAdmin] = @Original_IsAdmin) AND ((@IsNull_Password = 1 AND [Password] IS NULL) OR ([Password] = @Original_Password)) AND ((@IsNull_FirstName = 1 AND [FirstName] IS NULL) OR ([FirstName] = @Original_FirstName)) AND ((@IsNull_LastName = 1 AND [LastName] IS NULL) OR ([LastName] = @Original_LastName)) AND ((@IsNull_HomePhone = 1 AND [HomePhone] IS NULL) OR ([HomePhone] = @Original_HomePhone)) AND ((@IsNull_Email = 1 AND [Email] IS NULL) OR ([Email] = @Original_Email)) AND ((@IsNull_Address = 1 AND [Address] IS NULL) OR ([Address] = @Original_Address)) AND ((@IsNull_City = 1 AND [City] IS NULL) OR ([City] = @Original_City)) AND ((@IsNull_StateProvinceCode = 1 AND [StateProvinceCode] IS NULL) OR ([StateProvinceCode] = @Original_StateProvinceCode)) AND ((@IsNull_PostalCode = 1 AND [PostalCode] IS NULL) OR ([PostalCode] = @Original_PostalCode)) AND ([IsEnabled] = @Original_IsEnabled) AND ((@IsNull_DepartmentTypeID = 1 AND [DepartmentTypeID] IS NULL) OR ([DepartmentTypeID] = @Original_DepartmentTypeID)));
	
SELECT EmployeeID, IsAdmin, Password, FirstName, LastName, HomePhone, Email, Address, City, StateProvinceCode, PostalCode, IsEnabled, DepartmentTypeID FROM Employee WHERE (EmployeeID = @EmployeeID)
go

